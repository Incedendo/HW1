#include <stdio.h>
main()
{
	printf("Size of a char is %ld\n", sizeof(char));
	printf("Size of a short int is %ld\n", sizeof(short int));
	printf("Size of an int is %ld\n", sizeof(int));
	printf("Size of a long int is %ld\n", sizeof(long int));
	printf("Size of a long long int is %ld\n", sizeof(long long int));
	printf("Size of a char* is %ld\n", sizeof(char*));
	printf("Size of a float is %ld\n", sizeof(float));
	printf("Size of a double is %ld\n", sizeof(double));
}
